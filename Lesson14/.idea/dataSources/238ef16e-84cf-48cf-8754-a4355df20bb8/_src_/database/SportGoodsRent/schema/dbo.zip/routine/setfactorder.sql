create procedure dbo.setfactorder
  -- Add the parameters for the stored procedure here
    @customerid           int,
    @sportgoodid          int,
    @sportgoodtakendate   datetime,
    @sportgoodreturndate  datetime,
    @totaltopay           numeric(10, 2),
    @paid                 bit,
    @totalsportgoodstaken int
as
  begin
    -- SET NOCOUNT ON added to prevent extra result sets from
    -- interfering with SELECT statements.
    set nocount on;
    insert into dbo.factorder (
      customerid, sportgoodid, sportgoodtakendate, sportgoodreturndate, totaltopay, paid, totalsportgoodstaken
    )
      select
        @customerid,
        @sportgoodid,
        @sportgoodtakendate,
        @sportgoodreturndate,
        @totaltopay,
        @paid,
        @totalsportgoodstaken


  end
go
