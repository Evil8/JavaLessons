create procedure dbo.modifycustomer
  -- Add the parameters for the stored procedure here
    @id             int,
    @name       nvarchar(50) = null,
    @passportnumber nvarchar(20) = null,
    @address          nvarchar(100) = null,
    @active         bit = null
as
  begin
    -- SET NOCOUNT ON added to prevent extra result sets from
    -- interfering with SELECT statements.
    set nocount on;
    update dbo.customers
    set
      name       = coalesce(@name, name),
      address        = coalesce(@address, address),
      passportnumber = coalesce(@passportnumber, passportnumber),
      active         = coalesce(@active, active)
    where @id = id
  end
go
