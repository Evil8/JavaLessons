-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE TRIGGER dbo.TotalToPayCalculation
  ON dbo.FactOrder
AFTER  INSERT,UPDATE
AS
  BEGIN
    -- SET NOCOUNT ON added to prevent extra result sets from
    -- interfering with SELECT statements.
    SET NOCOUNT ON;

    Update fo Set totaltopay = priceperday*datediff(dd,i.sportgoodtakendate,i.sportgoodreturndate)
    from inserted i
    join dbo.factorder fo on i.id = fo.id
    join dbo.SportGoods sg On fo.sportgoodid = sg.id

    update sg set sg.totalamount = totalamount - i.totalsportgoodstaken
    from inserted i
    join dbo.sportgoods sg on i.sportgoodid = sg.id

END
go
