create procedure dbo.modifysportgood
  -- Add the parameters for the stored procedure here
    @id            int,
    @sportgoodname nvarchar(100) = null,
    @priceperday   numeric(5, 2) = null,
    @totalamount   int = null,
    @active        bit = null
as
  begin
    -- SET NOCOUNT ON added to prevent extra result sets from
    -- interfering with SELECT statements.
    set nocount on;
    update dbo.sportgoods
    set
      sportgoodname = coalesce(@sportgoodname, sportgoodname),
      priceperday   = coalesce(@priceperday, priceperday),
      totalamount   = coalesce(@totalamount, totalamount),
      active        = coalesce(@active, active)
    where @id = id
  end
go
