create procedure dbo.setsportgood
  -- Add the parameters for the stored procedure here
    @sportgoodsname nvarchar(100),
    @priceperday    numeric(5, 2),
    @totalamount    int
as
  begin
    -- SET NOCOUNT ON added to prevent extra result sets from
    -- interfering with SELECT statements.
    set nocount on;
    insert into dbo.sportgoods (
      sportgoodname, priceperday, totalamount
    )
      select
        @sportgoodsname,
        @priceperday,
        @totalamount

  end
go
