create procedure dbo.modifyfactorder
  -- Add the parameters for the stored procedure here
    @id                   int,
    @customerid           int = null,
    @sportgoodid          int = null,
    @sportgoodtakendate   datetime = null,
    @sportgoodreturndate  datetime = null,
    @totaltopay           numeric(10, 2) = null,
    @paid                 bit = null,
    @totalsportgoodstaken int = null,
    @closed               bit = null,
    @active               bit = null
as
  begin
    -- SET NOCOUNT ON added to prevent extra result sets from
    -- interfering with SELECT statements.
    set nocount on;

    update dbo.factorder
    set
      customerid           = coalesce(@customerid, customerid),
      sportgoodid          = coalesce(@sportgoodid, sportgoodid),
      sportgoodtakendate   = coalesce(@sportgoodtakendate, sportgoodtakendate),
      sportgoodreturndate  = coalesce(@sportgoodreturndate, sportgoodreturndate),
      totaltopay           = coalesce(@totaltopay, totaltopay),
      paid                 = coalesce(@paid, paid),
      totalsportgoodstaken = coalesce(@totalsportgoodstaken, totalsportgoodstaken),
      closed               = coalesce(@closed, closed),
      active               = coalesce(@active, active)
    where @id = id

  end
go
