CREATE procedure [dbo].[getcustomer]
  -- Add the parameters for the stored procedure here
    @id  int = null,
    @all bit
as
  begin
    -- SET NOCOUNT ON added to prevent extra result sets from
    -- interfering with SELECT statements.
    set nocount on;
    if (@all = 0 and @id is not null)
      begin
        select
          name,
		  passportnumber,
          address,
          active
        from dbo.customers
        where @id = id
      end
    else
      begin
        select
          id,
          name,
          passportnumber,
          address,
          active
        from dbo.customers

      end
  end
go
