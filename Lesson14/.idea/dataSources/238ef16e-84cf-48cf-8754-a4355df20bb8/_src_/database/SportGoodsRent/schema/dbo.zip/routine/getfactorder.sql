create procedure dbo.getfactorder
  -- Add the parameters for the stored procedure here
    @id int = null,
    @all bit
as
begin
    if (@all = 0 and @id is not null)
      begin
        select
          sportgoodid,
          customerid,
          totalsportgoodstaken,
          paid,
          closed,
          totaltopay,
          sportgoodtakendate,
          sportgoodreturndate
        from dbo.factorder
        where id = @id
      end
    else
      begin
         select
           id,
           sportgoodid,
           customerid,
           totalsportgoodstaken,
           paid,
           closed,
           totaltopay,
           sportgoodtakendate,
           sportgoodreturndate
         from dbo.factorder
      end
end
go
