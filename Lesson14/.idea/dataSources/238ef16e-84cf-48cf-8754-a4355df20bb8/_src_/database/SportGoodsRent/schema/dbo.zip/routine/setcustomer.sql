create procedure dbo.setcustomer
  -- Add the parameters for the stored procedure here
    @name       nvarchar(50),
    @passportnumber nvarchar(20),
    @address        nvarchar(500)

as
  begin
    -- SET NOCOUNT ON added to prevent extra result sets from
    -- interfering with SELECT statements.
    set nocount on;
    insert into dbo.customers (
      name, address, passportnumber
    )
      select
        @name,
        @address,
        @passportnumber

  end
go
